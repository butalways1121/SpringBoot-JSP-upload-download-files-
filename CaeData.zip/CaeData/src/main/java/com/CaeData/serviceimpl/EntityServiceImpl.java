package com.CaeData.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CaeData.dao.EntityDao;
import com.CaeData.entity.Entity;
import com.CaeData.service.EntityService;

@Service
public class EntityServiceImpl implements EntityService{

	@Autowired
	private EntityDao entityDao;
	
	
	public List<Entity> findAll() {
		// TODO 自动生成的方法存根
		return entityDao.findAll();
	}

	public boolean add(Entity entity) {
		// TODO 自动生成的方法存根
		boolean flag=true;
		try {
			entityDao.add(entity);
			flag=true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return flag;
	}

	public boolean delete(int id) {
		// TODO 自动生成的方法存根
		boolean flag=true;
		try {
			entityDao.delete(id);
			flag=true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return flag;
	}

	public Entity findById(int id) {
		// TODO 自动生成的方法存根
		return entityDao.findById(id);
	}

	public void update(Entity entity) {
		// TODO 自动生成的方法存根
		entityDao.update(entity);
	}

}

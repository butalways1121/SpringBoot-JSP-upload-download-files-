package com.CaeData.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.CaeData.entity.Entity;

@Mapper
public interface EntityDao {
	@Select("select * from caedata")
	List<Entity> findAll();//查找所有信息
	
	@Insert("insert into caedata(software,ip,server,address,port,license,date) values(#{software},#{ip},#{server},#{address},#{port},#{license},#{date})")
	void add(Entity entity);//添加一条信息
	
	@Delete("delete from caedata where id=#{id}")
	void delete(int id);//删除一条信息
	
	@Select("select * from caedata where id=#{id}")
	Entity findById(int id);//查找一条信息
	
	@Update("update caedata set software=#{software},ip=#{ip},server=#{server},address=#{address},port=#{port},license=#{license},date=#{date} where id=#{id}")
	void update(Entity entity);
}

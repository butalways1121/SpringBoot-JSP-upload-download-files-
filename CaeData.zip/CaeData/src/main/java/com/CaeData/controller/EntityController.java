package com.CaeData.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.CaeData.entity.Entity;
import com.CaeData.service.EntityService;

@Controller
public class EntityController {

	@Autowired
	private EntityService entityService;
	@Autowired
	private HttpServletRequest request;

	// 跳转到list页面，展示所有数据
	@RequestMapping(value = "/list")
	public String list(Model model) {
		System.out.println("查询所有信息！");
		List<Entity> entitys = entityService.findAll();
		// model是作为前后台的一个交互作用的,往前台传数据，可以传对象，可以传List，通过el表达式
		// ${}可以获取到，类似于request.setAttribute("sts",sts)效果一样
		model.addAttribute("entitys", entitys);
		return "list";
	}

	// 删除一条信息
	@RequestMapping("/toDelete")
	public String delete(int id) {
		entityService.delete(id);
		System.out.println("删除成功！");
		return "redirect:/list";
	}

	// 添加信息时跳转先转到uploadnew页面
	@RequestMapping("/toAdd")
	public String toAdd() {
		return "uploadnew";
	}

	// uploadnew页面上传文件,上传完成之后返回add页面完善其他信息
	@PostMapping("/uploadnew")
	public String uploadnew(@RequestParam("file") MultipartFile file) {
		if (file.isEmpty()) {
			request.setAttribute("message", "上传失败，请选择文件！");
			return "message";
		}
		String fileName = file.getOriginalFilename();
		//String filePath = request.getSession().getServletContext().getRealPath("/") + "upload/";
		String filePath ="D://CAE/license/";
		File dest = new File(filePath + fileName);
		// 判断文件父目录是否存在
		if (!dest.getParentFile().exists()) {
			dest.getParentFile().mkdir();
		}
		try {
			file.transferTo(dest);
			request.setAttribute("message", fileName);
			return "add";
		} catch (IOException e) {
			request.setAttribute("message", "上传失败！");
			return "message";
		}
	}

	// 添加一条信息，添加完成之后转到list页面
	@RequestMapping("/add")
	public String add(Entity entity) {
		entityService.add(entity);
		System.out.println("添加成功！");
		return "redirect:/list";
	}

	// 点击编辑跳转到选择uploadrenew页面选择上传文件或直接下一步
	@RequestMapping("/toEdit")
	public String toEdit(Model model, @RequestParam("id") int id) {
		model.addAttribute("id", id);
		return "uploadrenew";
	}

	// uploadrenew页面选择上传文件
	@PostMapping("/uploadrenew1")
	public String uploadrenew1(@RequestParam("file") MultipartFile file,
			@RequestParam("id") int id, 
			Model model) {
		if (file.isEmpty()) {
			request.setAttribute("message", "上传失败，请选择文件！");
			return "message";
		}
		String fileName = file.getOriginalFilename();
		//String filePath = request.getSession().getServletContext().getRealPath("/") + "upload/";
		String filePath = "D://CAE/license/";
		File dest = new File(filePath + fileName);
		Entity entity = entityService.findById(id);
		// 判断文件父目录是否存在
		if (!dest.getParentFile().exists()) {
			dest.getParentFile().mkdir();
		}
		try {
			file.transferTo(dest);
			entity.setLicense(fileName);
			model.addAttribute("entity", entity);
			return "edit";
		} catch (IOException e) {
			request.setAttribute("message", "上传失败！");
			return "message";
		}
	}

	// uploadrenew页面选择下一步
	@PostMapping("/uploadrenew2")
	public String uploadrenew2(@RequestParam("id") int id, 
			Model model) {
		Entity entity = entityService.findById(id);
		model.addAttribute("entity", entity);
		return "edit";
	}

	// 编辑完信息后转到list页面
	@RequestMapping("/edit")
	public String edit(Entity entity) {
		entityService.update(entity);
		return "redirect:/list";
	}

	// list下载下载文件
	@GetMapping("/testDownload")
	//HttpServletResponse是一个继承了ServletResponse的接口，这个对象中封装了向客户端发送数据、发送响应头，发送响应状态码的方法
	public void testDownload(HttpServletResponse res,
			@RequestParam(value = "license", required = true) String fileName) {
		res.setHeader("content-type", "application/octet-stream");//Content-Type的作用：该实体头的作用是让服务器告诉浏览器它发送的数据属于什么文件类型,application/octet-stream意思是八进制文件
		res.setContentType("application/octet-stream");
		res.setHeader("Content-Disposition", "attachment;filename=" + fileName);
		//以上三句用于设置文件下载的头
		byte[] buff = new byte[1024];//设置缓冲区
		BufferedInputStream bis = null;//BufferedInputStream创建缓存输入流对象
		OutputStream os = null;//OutputStream输出流
		try {
			os = res.getOutputStream();//getOutputStream()方法用于返回Servlet引擎创建的字节输出流对象，Servlet程序可以按字节形式输出响应正文
			bis = new BufferedInputStream(new FileInputStream(
					new File("D://CAE/license/"+fileName)));
			//FileInputStream(path);使用IO读取到改文件，path为要下载文件的绝对路径；
			int i = bis.read(buff);
			while (i != -1) {
				os.write(buff, 0, buff.length);
				os.flush();
				i = bis.read(buff);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (bis != null) {
				try {
					bis.close();//关闭资源
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println("success");
	}

}

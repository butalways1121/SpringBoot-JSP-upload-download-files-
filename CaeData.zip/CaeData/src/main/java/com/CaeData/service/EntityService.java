package com.CaeData.service;

import java.util.List;

import com.CaeData.entity.Entity;

public interface EntityService {
	List<Entity> findAll();
	boolean add(Entity entity);
	boolean delete(int id);
	Entity findById(int id);
	void update(Entity entity);
}
